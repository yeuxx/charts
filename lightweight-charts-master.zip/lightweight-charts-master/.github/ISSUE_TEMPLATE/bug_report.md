---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**Lightweight Charts™ Version:** <!-- 1.0.0 -->

**Steps/code to reproduce:**

<!--
```js
```
-->

**Actual behavior:**

<!-- A clear and concise description of what actually happen. -->

**Expected behavior:**

<!-- A clear and concise description of what you expected to happen. -->

**Screenshots:**

<!-- If applicable, add screenshots to help explain your problem. -->

**CodeSandbox/JSFiddle/etc link:**

<!-- If applicable, add create a repro of the problem in any playground you wish. -->
