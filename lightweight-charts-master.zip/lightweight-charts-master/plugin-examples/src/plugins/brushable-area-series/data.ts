import { CustomData } from 'lightweight-charts';

/**
 * BrushableArea Series Data
 */
export interface BrushableAreaData extends CustomData {
	value: number;
}
